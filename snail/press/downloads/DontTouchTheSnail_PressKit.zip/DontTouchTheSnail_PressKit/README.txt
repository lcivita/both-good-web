Don’t Touch the Snail – Press Kit

All assets in this folder are free to use for editorial coverage,
streams, videos, and previews of the game.

Trailer downloads can be found at: https://drive.google.com/file/d/10loNZ436nIKSR7ClD1hW4GeTwkyM4Qr_/view?usp=sharing

Contact: press@bothgood.games
Steam: https://store.steampowered.com/app/4149320/